<?php

header('Location: google.html');
?>