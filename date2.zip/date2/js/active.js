(function($) {
    'use strict';
    $('.count').rCounter();
})(jQuery);